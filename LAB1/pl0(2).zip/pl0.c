// pl0 compiler source code
//pl6
#pragma warning(disable:4996)


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#include "PL0.h"
#include "set.c"

//////////////////////////////////////////////////////////////////////
// print error message.
void error(int n)//???3???????????D?????n?a??????????D???????????D???�y?????D?????????????????????��?y
{
	int i;

	printf("      ");
	for (i = 1; i <= cc - 1; i++)
		printf(" ");
	printf("^\n");
	printf("Error %3d: %s\n", n, err_msg[n]);
	err++;
} // error

//////////////////////////////////////////////////////////////////////
int note = 0;
void getch(void)
{
	if (cc == ll)
	{
		if (feof(infile))    //
		{
			printf("\nPROGRAM INCOMPLETE\n");
			exit(1);
		}
		ll = cc = 0;
		if(!note)
		{
			printf("%5d  ", cx);
		}
		else
		{
			printf("       ");
		}
		while ((!feof(infile)) // added & modified by alex 01-02-09
			&& ((ch = getc(infile)) != '\n'))
		{
			printf("%c", ch);
			line[++ll] = ch;
		} // while
		printf("\n");
		line[++ll] = ' ';
	}
	ch = line[++cc];
} // getch

//////////////////////////////////////////////////////////////////////
// gets a symbol from input stream.
void getsym(void)
{
	int i, k;
	char a[MAXIDLEN + 1];
	int end = 1;
    int abc_i = 0;
    char abc[10000] = {0};

	while (ch == ' ' || ch == '\t')
		getch();

	if (isalpha(ch))
	{ // symbol is a reserved word or an identifier. or a goto chance
		k = 0;
		do
		{
			if (k < MAXIDLEN)
				a[k++] = ch;
			getch();
		} while (isalpha(ch) || isdigit(ch));
		a[k] = 0;
		strcpy(id, a);
		word[0] = id;
		i = NRW;
		while (strcmp(id, word[i--]));
		if (++i)
			sym = wsym[i]; // symbol is a reserved word
		else
		{
			if(ch == '[')
			{
            	sym = SYM_ARRAY;
				strcpy(id_array, id);
				id_array_used = 1;
			}
			else
				sym = SYM_IDENTIFIER;  
    	}
	}
	else if (isdigit(ch))
	{ // symbol is a number.
		k = num = 0;
		sym = SYM_NUMBER;
		do
		{
			num = num * 10 + ch - '0';
			k++;
			getch();
		} while (isdigit(ch));
		if (k > MAXNUMLEN)
			error(25);     // The number is too great.
	}
	else if (ch == ':')
	{
		getch();
		if (ch == '=')
		{
			sym = SYM_BECOMES; // :=
			getch();
		}
		else
		{
			sym = SYM_COLON;     // :
		}
	}
	else if (ch == '>')
	{
		getch();
		if (ch == '=')
		{
			sym = SYM_GEQ;     // >=
			getch();
		}
		else
		{
			sym = SYM_GTR;     // >
		}
	}
	else if (ch == '<')
	{
		getch();
		if (ch == '=')
		{
			sym = SYM_LEQ;     // <=
			getch();
		}
		else if (ch == '>')
		{
			sym = SYM_NEQ;     // <>
			getch();
		}
		else
		{
			sym = SYM_LES;     // <
		}
	}
	else if (ch == '&')
	{
		getch();
		if (ch == '&')
		{
			sym = SYM_AND;
			getch();
		}
		else
		{
			sym = SYM_ADDRESS;
		}
	}
	else if (ch == '|')
	{
		getch();
		if (ch == '|')
		{
			sym = SYM_OR;
			getch();
		}
		else
		{
			sym = SYM_OP_OR;
		}
	}
	else if (ch == '!')
	{
		getch();
		sym = SYM_NOT;
	}
	else if(ch == '/')
    {
		getch();
        if(ch == '*') // "/*"��note
        {
			note = 1;
			getch();
            
            while(end)
            { 
                if(ch == '*')
                {
                    abc[abc_i++] = ch;
                    getch();
                    if(ch == '/')
                    {
                        end = 0;
                        abc[abc_i-1] = 0;
                        printf("Notes Start:\n");
                        printf("%s\n", abc);
                        printf("Notes Finish.\n");
                    }
                    else
                    {
                        abc[abc_i++] = ch;
                        getch();
                    }
                }
				else if (cc == ll)
				{   abc[abc_i++] = '\n';
                    getch();
                }
				else
				{   abc[abc_i++] = ch;
                    getch();
                }
            }
			note = 0;
			getch();
        	getsym();
        }
        else if(ch == '/') // "//"��note
        {
			note = 1;
			printf("Notes Start:\n");
            while(cc != ll)
            {
                getch();
                printf("%c",ch);
            }
            printf("\nNotes Finish.\n");
			note = 0;
			getch();
        	getsym();
        }
		else //�����?
		{
			csym[0] = '/';
			sym = SYM_SLASH;
		}
    }
	else
	{ // other tokens
		i = NSYM;
		csym[0] = ch;
		while (csym[i--] != ch);
		if (++i)
		{
			sym = ssym[i];
			getch();
		}
		else
		{
			printf("Fatal Error: Unknown character.\n");
			exit(1);
		}
	}
} // getsym

//////////////////////////////////////////////////////////////////////
// generates (assembles) an instruction.
void gen(int x, int y, int z)
{
	if (cx > CXMAX)
	{
		printf("Fatal Error: Program too long.\n");
		exit(1);
	}
	code[cx].f = x;
	code[cx].l = y;
	code[cx++].a = z;
} // gen

void gen_temp(int x, int y, int z, int level)
{//??vardeclaration?????��?????
	code_temp[tempx].f = x;
	code_temp[tempx].l = y;
	code_temp[tempx].a = z;
	code_temp[tempx++].level = level;
} // gen

void print_codetemp(int level)
{//?????level??????????????????????????
	int i = 0;
	int temp = tempx - 1;
	while (i <= temp)
	{
		if (level == code_temp[i].level)
		{
			gen(code_temp[i].f, code_temp[i].l, code_temp[i].a);
			tempx--;
		}
		i++;
	}
}

//////////////////////////////////////////////////////////////////////
// tests if error occurs and skips all symbols that do not belongs to s1 or s2.
void test(symset s1, symset s2, int n)
{
	symset s;

	if (!inset(sym, s1))
	{
		error(n);
		s = uniteset(s1, s2);
		while (!inset(sym, s))
			getsym();
		destroyset(s);
	}
} // test

//////////////////////////////////////////////////////////////////////
int dx;  // data allocation index

int position(char*);
// enter object(constant, variable or procedre) into table.
void enter(int kind)
{
	mask* mk;
	if (position(id) > 0&&sym!=SYM_RSPAREN)
	{
		mk = (mask*)&table[tx];
		mk->level = level;
		mk->address = dx++;
	}
	else {
		tx++;
		if(id_array_used == 0)
			strcpy(table[tx].name, id);
		else
			strcpy(table[tx].name, id_array);
		table[tx].kind = kind;
		switch (kind)
		{
		case ID_CONSTANT:
			if (num > MAXADDRESS)
			{
				error(25); // The number is too great.
				num = 0;
			}
			table[tx].value = num;
			break;
		case ID_REFERENCE:	
		case ID_VARIABLE:
			mk = (mask*)&table[tx];
			mk->level = level;
			mk->address = dx++;
			break;
		case ID_PROCEDURE:
			mk = (mask*)&table[tx];
			mk->level = tx2;
			tx2++;
			break;
		}// switch
	}
} // enter

void array_enter()
{
	int i;
	ax++;
	array_table[ax] = array_t;
	strcpy(array_table[ax].name, id_array);
	enter(ID_VARIABLE);
	array_table[ax].address = tx; //��¼�����ʼƫ�Ƶ��?
	for ( i = array_table[ax].sum - 1; i > 0;i--)
	{
		enter(ID_VARIABLE);      //���������д洢�ռ�����table
	}
	id_array_used = 0;
}

int array_position()
{
	int i;
	strcpy(array_table[0].name, id_array);
	i = ax + 1;
	while (strcmp(array_table[--i].name, id_array) != 0);
	return i;
}
int array_position2(char*s)
{
	int i;
	strcpy(array_table[0].name,s);
	i = ax + 1;
	while (strcmp(array_table[--i].name, s) != 0);
	return i;
}

void ref_enter()
{
	rx++;
	strcpy(ref_table[rx].name, id);
	ref_table[rx].kind = ID_VARIABLE;
	ref_table[rx].level = level;
	enter(ID_VARIABLE);
	//ref_table[rx].addr = tx; //???????table?��?????
}//ref_enter

///////////////////////////////////////////
// assign address

void ref_addr(char* id)
{ /* ?????? var &y = x?��??????y?????????????
	?????getsym??x?????x??table?��?��?????ref_table
	??y????????addr?????.	  */

	int i = position(id);
	if (i == 0) return;
	ref_table[rx].addr = i;
}// ref_addr

/////////////////////////////////////////
//locates identifier in ref_table
int ref_position(char* id)
{// id?????????????????????????????????????????��?��??
	int i;
	strcpy(ref_table[0].name, id);
	i = rx + 1;
	while (strcmp(ref_table[--i].name, id) != 0);
	return i;
}//ref_position

int is_refered(char *id)
{// id????????????????????????id?????????????��?��????????��???0
	int pos = position(id);//pos??id????????��?��??
	int i = rx + 1;
	if (pos == 0) return -1;		
	ref_table[0].addr = pos;
	while (ref_table[--i].addr != pos);
	return i;
}//is_refered

//////////////////////////////////////////////////////////////////////
// locates identifier in symbol table.
int position(char* id)
{
	int i;
	mask* mk;
	strcpy(table[0].name, id);
	i = tx + 1;
	while (strcmp(table[--i].name, id) != 0);
	mk = (mask*)&table[i];
	if (i && mk->level < level)return 0;	//?????????????��?��
	return i;
} // position

//////////////////////////////////////////////////////////////////////
void constdeclaration()
{
	if (sym == SYM_IDENTIFIER)
	{
		getsym();
		if (sym == SYM_EQU || sym == SYM_BECOMES)
		{
			if (sym == SYM_BECOMES)
				error(1); // Found ':=' when expecting '='.
			getsym();
			if (sym == SYM_NUMBER)
			{
				enter(ID_CONSTANT);
				getsym();
			}
			else
			{
				error(2); // There must be a number to follow '='.
			}
		}
		else
		{
			error(3); // There must be an '=' to follow the identifier.
		}
	}
	else	error(4);
	// There must be an identifier to follow 'const', 'var', or 'procedure'.
} // constdeclaration

void expression(symset fsys);
//////////////////////////////////////////////////////////////////////
void vardeclaration(void)
{
	mask* mk;
	int i,j;
	symset fsys,set;
	if (sym == SYM_IDENTIFIER)
	{
		enter(ID_VARIABLE);//????????????????
		getsym();
	}
	else if (sym == SYM_ADDRESS) 
	{
		getsym();
		if (sym == SYM_IDENTIFIER)
		{
			enter(ID_REFERENCE);
			getsym();
			if (sym == SYM_EQU)
			{
				getsym();
				if (sym == SYM_IDENTIFIER)
				{
					if ((i = position(id)) != 0)
					{
						mk = (mask*)&table[i];
						if(mk->kind == ID_VARIABLE)
						{
							gen_temp(LEA, level - mk->level, mk->address, level);//取变量地址
							mk = (mask*)&table[tx];
							gen_temp(STO, level - mk->level, mk->address, level);//存进引用变量中
							getsym();
						}
						else if(mk->kind == ID_REFERENCE)
						{
							gen_temp(LOD, level- mk->level, mk->address, level);
							mk = (mask*)&table[tx];
							gen_temp(STO, level - mk->level, mk->address, level);
							getsym();
						}
					}
					else
					{
						error(11); // ????��????
					}
				}
				
				else if(sym == SYM_ARRAY)
				{
					if(!(i = array_position()))
						error(11);
					else
					{
						j = array_table[i].address;
						mk = (mask*) &table[j];
						if(mk->kind == ID_VARIABLE)
						{//3.txt, 不要修改
							gen_temp(LIT, 0, 0, level);
							while(ch == '[')
							{
								d++;
								getch();
								getsym();
								/*
								fsys = createset(SYM_CONST, SYM_VAR, SYM_NULL);
								set = uniteset(createset(SYM_RSPAREN, SYM_NULL),fsys);
								expression(set);//there is a problem
								destroyset(set);
								*/
								if(sym == SYM_NUMBER)
								{
									gen_temp(LIT, 0, num, level);
								}
								else if(sym == SYM_IDENTIFIER)
								{
									mask* mk1;
									int k = position(id);
									mk1 = (mask*)&table[k];
									gen_temp(LOD, 0, mk1->address, level);//there is a problem
								}
								gen_temp(LIT, 0, array_table[i].size[d], level);
								gen_temp(OPR, 0, OPR_MUL, level);
								gen_temp(OPR, 0, OPR_ADD, level);
								getch();
							}
							d = 0;
							gen_temp(LEA, 0, mk->address, level);
							//gen_temp(LOD, 0, mk->address, level);
							gen_temp(OPR, 0, OPR_ADD, level);
							mk = (mask*)&table[tx];
							gen_temp(STO, level - mk->level, mk->address, level);//���ַ�����ñ�����
							getsym();
						}
						else if(mk->kind == ARR_PARAREF)
						{// ref700.txt
							gen_temp(LIT, 0, 0, level);
							while(ch == '[')
							{
								d++;
								getch();
								getsym();
								/*
								fsys = createset(SYM_CONST, SYM_VAR, SYM_NULL);
								set = uniteset(createset(SYM_RSPAREN, SYM_NULL),fsys);
								expression(set);//there is a problem
								destroyset(set);
								*/
								if(sym == SYM_NUMBER)
								{
									gen_temp(LIT, 0, num, level);
								}
								else if(sym == SYM_IDENTIFIER)
								{
									mask* mk1;
									int k = position(id);
									mk1 = (mask*)&table[k];
									gen_temp(LOD, 0, mk1->address, level);//there is a problem
								}
								gen_temp(LIT, 0, array_table[i].size[d], level);
								gen_temp(OPR, 0, OPR_MUL, level);
								gen_temp(OPR, 0, OPR_ADD, level);
								getch();
							}
							d = 0;
							gen_temp(LOD, 0, mk->address, level);
							gen_temp(OPR, 0, OPR_ADD, level);
							mk = (mask*)&table[tx];
							gen_temp(STO, level - mk->level, mk->address, level);//���ַ�����ñ�����
							getsym();
						}
					}
					
					id_array_used = 0;
				}//end of sym_array
				else
				{
					error(26); //??????????????????
				}
			}
			else
			{
				error(3); // ??????????'='
			}
		}
	}
	else if(sym == SYM_ARRAY)
	{
		d = 0;
		while (ch == '[')
		{
			d++;
			getch();
			getsym();
			if(sym == SYM_NUMBER)
			{
				gen(LIT, 0, num);
				array_t.dim[d] = num;
			}
			else if(sym == SYM_IDENTIFIER)
			{
				if ((i = position(id)) == 0)
				{
					error(11); // Undeclared identifier.
				}	
				else
				{
					array_t.dim[d] = table[i].value;
					switch (table[i].kind)
					{
						mask* mk;
					case ID_CONSTANT:
						gen(LIT, 0, table[i].value);
						break;
					case ID_VARIABLE:
						mk = (mask*)&table[i];
						gen(LOD, level - mk->level, mk->address);
						break;
					}
				}
			}
			getsym();
		}
		array_t.n = d;
		array_t.size[d] = 1; //������ƫ������СΪ1
		for (i = d; i >= 2;i--)
		{
			array_t.size[i - 1] = array_t.size[i] * array_t.dim[i];
		}
		array_t.sum = array_t.size[1] * array_t.dim[1];
		array_enter();
		d = 0;
		getsym();
	}
	else
	{
		error(4); // There must be an identifier to follow 'const', 'var', or 'procedure'.
	}
} // vardeclaration

//////////////////////////////////////////////////////////////////////
void listcode(int from, int to)
{
	int i;

	printf("\n");
	for (i = from; i < to; i++)
	{
		printf("%5d %s\t%d\t%d\n", i, mnemonic[code[i].f], code[i].l, code[i].a);
	}
	printf("\n");
} // listcode

//address the element of array
//void call(int i, symset fsys);
//////////////////////////////////////////////////////////////////////
void factor(symset fsys)
{
	void expression(symset fsys);
	int i;
	mask* mk;
	symset set;

	test(facbegsys, fsys, 24); // The symbol can not be as the beginning of an expression.

	if (inset(sym, facbegsys))
	{
		if (sym == SYM_IDENTIFIER)
		{
			if ((i = position(id)) == 0)
			{
				error(11); // Undeclared identifier.
			}
			else
			{
				switch (table[i].kind)
				{
					
				case ID_CONSTANT:
					gen(LIT, 0, table[i].value);
					break;
				case ID_VARIABLE:
					mk = (mask*)&table[i];
					gen(LOD, level - mk->level, mk->address);
					break;
				case ID_PROCEDURE:
					error(21); // Procedure identifier can not be in an expression.
					break;
				case ID_REFERENCE:
					mk = (mask*)&table[i];
					gen(MOV, level - mk->level, mk->address);
					gen(LODR, /*level - mk->level*/0 , 0);
					break;
				case ID_PARAREF://����ַ������
					mk = (mask*) &table[i];
					gen(LOD, level - mk->level, mk->address);
					gen(LODA, 1, 0);
					break;
				} // switch
			}
			getsym();
		}
		else if (sym == SYM_NUMBER)
		{
			if (num > MAXADDRESS)
			{
				error(25); // The number is too great.
				num = 0;
			}
			gen(LIT, 0, num);
			getsym();
		}
		else if (sym == SYM_LPAREN)
		{
			getsym();
			set = uniteset(createset(SYM_RPAREN, SYM_NULL), fsys);
			expression(set);
			destroyset(set);
			if (sym == SYM_RPAREN)
			{
				getsym();
			}
			else
			{
				error(22); // Missing ')'.
			}
		}
		else if (sym == SYM_MINUS) // UMINUS,  Expr -> '-' Expr
		{
			getsym();
			expression(fsys);
			gen(OPR, 0, OPR_NEG);
		}
		else if(sym == SYM_ARRAY)
    	{
			if(!(i = array_position()))
				error(11);
			else
			{
				int j = array_table[i].address;
				mk = (mask *)&table[j];
				gen(LIT, 0, 0); //ͨ���ۼ�����ƫ������ȷ��Ԫ��λ��
				while(ch == '[')
				{
					d++;
					getch();
					getsym();
					set = uniteset(createset(SYM_RSPAREN, SYM_NULL),fsys);
					expression(set);
					destroyset(set);
					gen(LIT, 0, array_table[i].size[d]);
                	//ȡ��ǰά����ƫ������ֵ����ջ��
					gen(OPR, 0, OPR_MUL);
                	//��ǰά����ֵ���Ե�ǰά����ƫ������ֵ����ջ��
					gen(OPR, 0, OPR_ADD);//�ۼӵ���ƫ��
				}
				d = 0;
				if( j ){
					if(mk -> kind == ID_VARIABLE){	
						gen(LDA, level - mk->level, mk->address);
					}
            	//���ɼ�������ָ���¼����ƫ��
					//����ǲ�����������?
					else if(mk -> kind == ARR_PARAREF){
						gen(LOD , level - mk->level, mk->address);
						gen(OPR, 0 ,OPR_ADD);
						gen(LODA, 1, 0);
					}
				}
			}
			getsym();
		}
		else if (sym == SYM_RANDOM)
		{
			getsym();
			if (sym == SYM_LPAREN)
			{
				getsym();
				if (sym == SYM_RPAREN)
				{
					//num_random = rand() % 10000;
					//gen(LIT, 0, num_random);
					gen(RAN, 0, 0);
					getsym();
				}
				else if (sym == SYM_NUMBER)
				{
					//num_random = rand() % (num + 1);
					//gen(LIT, 0, num_random);
					gen(RAN, 0, num);
					getsym();
					if (sym == SYM_RPAREN)
					{
						getsym();
					}
				}
				else
				{
					error(34);
				}
			}
			else
			{
				error(35);
			}
		}
		test(fsys, createset(SYM_LPAREN, SYM_NULL), 23);
	} // while
} // factor

//////////////////////////////////////////////////////////////////////
void term(symset fsys)
{
	int mulop;
	symset set;

	set = uniteset(fsys, createset(SYM_TIMES, SYM_SLASH,SYM_LSPAREN, SYM_RSPAREN, SYM_NULL));
	factor(set);
	while (sym == SYM_TIMES || sym == SYM_SLASH)
	{
		mulop = sym;
		getsym();
		factor(set);
		if (mulop == SYM_TIMES)
		{
			gen(OPR, 0, OPR_MUL);
		}
		else
		{
			gen(OPR, 0, OPR_DIV);
		}
	} // while
	destroyset(set);
} // term

//////////////////////////////////////////////////////////////////////
void expression(symset fsys)
{
	int addop;
	symset set;
	set = uniteset(fsys, createset(SYM_PLUS, SYM_MINUS, SYM_LSPAREN, SYM_RSPAREN,SYM_NULL));
	term(set);
	while (sym == SYM_PLUS || sym == SYM_MINUS)
	{
		addop = sym;
		getsym();
		term(set);
		if (addop == SYM_PLUS)
		{
			gen(OPR, 0, OPR_ADD);
		}
		else
		{
			gen(OPR, 0, OPR_MIN);
		}
	} // while

	destroyset(set);
} // expression
//////////////////////////////////////////////////////////////////////
void condition(symset fsys);
int condition_1(symset fsys)
{
	int relop;//������ʱ�洢token������ 
	symset set;
	int flag = 0;//???????????? 
	int true0 = count1;
	int false0 = count0;
	int notflag = 0;//??????!?????? 
	
	if (sym==SYM_NOT)//?????not????? 
	{
		getsym();
		notflag=1;//֤����not 
	}
	else if (sym == SYM_ODD)
	{
		getsym();
		expression(fsys);
		gen(OPR, 0, 6);
	}
	else if (sym == SYM_LPAREN)//?????????????? 
	{
		getsym();
		set = uniteset(createset(SYM_RPAREN, SYM_NULL), fsys);
		condition(set);
		if(notflag==0) 
		{
			if(count0==0)
			{
				gen(JMP, 0, 0);
				falselist[count0++]=cx-1;
			}
			while(count1!=0)
			{
				count1--;
				code[truelist[count1]].a = cx;
			}
		}
		destroyset(set);
		flag=1;
		if (sym == SYM_RPAREN)
		{
			getsym();
		}
		else
		{
			error(22); // Missing ')'.
		}
	}
	else
	{
		set = uniteset(relset, fsys);//relset?�՛�???????? 
		expression(set);//�Ա���ʽ��߽��д���? 
		destroyset(set);
		if (!inset(sym, relset))
		{
			gen(JNZ, 0, 0);
			//error(20);
		}
		else
		{
			relop = sym;// 
			getsym();
			expression(fsys);//�Ա���ʽ�ұ߽��д��� 
			switch (relop)
			{
			case SYM_EQU:
				gen(JE, 0, 0);
				break;
			case SYM_NEQ:
				gen(JNE, 0, 0);
				break;
			case SYM_LES:
				gen(JL, 0, 0);
				break;
			case SYM_GEQ:
				gen(JGE, 0, 0);
				break;
			case SYM_GTR:
				gen(JG, 0, 0);
				break;
			case SYM_LEQ:
				gen(JLE, 0, 0);
				break;
			} // switch
		} // else
	}// else
	if (notflag==1)
	{
		while(count1>true0)
		{
			count1--;
			code[truelist[count1]].a = cx;
		}
		while (count0>false0)
		{
			count0--;
			truelist[count1++] = falselist[count0];
		} 
	}//���� 
	return flag;
}// condition

void condition_2(symset fsys)
{
	int flag;
	symset set;
	set = uniteset(fsys, createset(SYM_AND, SYM_NULL));
	flag = condition_1(set);//???��?????????????? 
	if (!flag && sym == SYM_AND)
	{
		code[cx - 1].f = 33 - code[cx - 1].f;
		falselist[count0++] = cx - 1;//and????????????????????????????????? 
	}
	while (sym == SYM_AND)
	{
		getsym();
		flag = condition_1(set);
		if (!flag)
		{
			code[cx - 1].f = 33 - code[cx - 1].f;
			falselist[count0++] = cx - 1;//and????????????????????????????????? 
		}
		if (!count0)
		{
			gen(JMP, 0, 0);
			falselist[count0++] = cx - 1;
		}
	} // while
	destroyset(set);
}

void condition(symset fsys)
{
	symset set;
	set = uniteset(fsys, createset(SYM_OR, SYM_NULL));
	condition_2(set);
	while (sym == SYM_OR)//????????or 
	{
		while (count0)
		{
			count0--;
			code[falselist[count0]].a = cx;
		}//or????????��??????????????�� 
		truelist[count1++] = cx - 1;//or??????????????????? 
		getsym();
		condition_2(set);
	} // while
	truelist[count1++] = cx - 1;//or??????????????????? 
	destroyset(set);
}

void call(int i, symset fsys)
{
    mask* mk;
    mask* mk1,*mk2;
	symset set1, set;
	int j,a,m;
    int count = 0;
    mk = (mask*) &table[i];
    getsym();
	
    if(sym == SYM_LPAREN)
    {
        do
        {
            getsym();
			if( table2[mk->level].type[count+1] == 0 )
			{
				set1 = createset(SYM_COMMA, SYM_RPAREN, SYM_NULL);
				set = uniteset(set1, fsys);
				expression(set);
				destroyset(set1);
				destroyset(set);
				
			}
			/******************/
			else if(table2[mk->level].type[count+1] == 2){		//传数组

				if(sym == SYM_IDENTIFIER){
					if (! (j = array_position2(id)))
					{	
						error(11); // Undeclared identifier.
					}
					
					else if(array_table[j].n == table2[mk->level].array[count+1].n )
					
					{	
						for(a = 1;a <= array_table[j].n;a++){
							if(array_table[j].dim[a] != table2[mk->level].array[count+1].dim[a]) {error(29);break;}
						}
						mk1 = (mask*) &table[array_table[j].address];
						gen(LEA, 0, mk1->address);		//LEAȡ��ַ
						getsym();
					}
					else{
						error(29);
					}

				}
										
			}
			else	
			{	
				if(sym == SYM_ARRAY)	//array num
    			{
					if(!(m = array_position()))
						error(11);
					else
					{
						j = array_table[m].address;
						mk2 = (mask *)&table[j];
						gen(LIT, 0, 0); //ͨ���ۼ�����ƫ������ȷ��Ԫ��λ��
						while(ch == '[')
						{
							d++;
							getch();
							getsym();
							set = uniteset(createset(SYM_RSPAREN, SYM_NULL),fsys);
							expression(set);
							destroyset(set);
							gen(LIT, 0, array_table[m].size[d]);
                			//ȡ��ǰά����ƫ������ֵ����ջ��
							gen(OPR, 0, OPR_MUL);
                			//��ǰά����ֵ���Ե�ǰά����ƫ������ֵ����ջ��
							gen(OPR, 0, OPR_ADD);//�ۼӵ���ƫ��
						}
						d = 0;
						if( j ){							
								gen(LEA , 0, mk2->address);
								gen(OPR, 0 ,OPR_ADD);
						}
					}
				
					getsym();
				}
				else if(sym == SYM_IDENTIFIER)
				{				
					if (! (j = position(id)))
					{
						error(11); // Undeclared identifier.
					}
					else if (table[j].kind == ID_VARIABLE ){	
						mk1 = (mask*) &table[j];
						gen(LEA, 0, mk1->address);		//�ĳ�LEAȡ��ַ
						getsym();	
						if(sym != SYM_COMMA && sym != SYM_RPAREN)error(29);//���ʹ���Type of parameter dismatch
					}
					else if(table[j].kind == ID_REFERENCE ){
						mk1 = (mask*) &table[j];
						gen(LOD,0,mk1->address);
						getsym();	
						if(sym != SYM_COMMA && sym!= SYM_RPAREN)error(29);//���ʹ���Type of parameter dismatch
					}
					else error(29); //���ʹ���Type of parameter dismatch
				}
				else error(29);	//���ʹ���Type of parameter dismatch
			}
			count++;
		}			
        while(sym == SYM_COMMA);
		//��Ҫ�жϲ��������Ƿ�һ�£���Ҫ�ں�������ʱ��¼���������Ͳ�������
		if(table2[mk->level].varnum != count)error(28);	//����������һ��*******
		
        if(sym == SYM_RPAREN)
            getsym();
        else
            error(22);		//ȱ��������
        gen(CAL, level - mk->level, mk->address);	//���ú���
		gen(POPN, 0, count);
		
	}
    else error(16);

}

//int loop1;
//////////////////////////////////////////////////////////////////////
void statement(symset fsys)
{
	int i, cx1, j, flag;
	int false0;
	int list0[100];
	symset set1, set, set2, set3;
	int jump[100];
	int list = 0;
	int ex = 0;
	int loop1,loop2;
	mask* mk;

	if (sym == SYM_IDENTIFIER)
	{ // variable assignment
		if (!(i = position(id)))
		{
			getsym();
			if (sym == SYM_COLON)
			{
				set1 = createset(SYM_COLON, SYM_NULL);
				fsys = uniteset(set1, fsys);
				destroyset(set1);
				flag = 0;
				for (j = 0; j < labelnum; j++)
				{
					if (!strcmp(labelchar[j], id))
						flag = 1;
				}
				if (flag)
					error(31);
				else {
					strcpy(labelchar[labelnum], id);
					labela[labelnum] = cx;
					labelnum++;
				}
				getsym();
			}
			else
				error(11);
			test(fsys, phi, 19);
			statement(fsys);
			// Undeclared identifier.
		}
		else if (table[i].kind == ID_VARIABLE || table[i].kind == ID_REFERENCE || table[i].kind == ID_PARAREF) 
		{
			getsym();
			if (sym == SYM_BECOMES)
			{
				getsym();
			}
			else
			{
				error(13); // ':=' expected.
			}
			
			mk = (mask*)&table[i];
			if (i)
			{
				//gen(STO, level - mk->level, mk->address);
				if (mk->kind == ID_VARIABLE)
				{	
					expression(fsys);
					gen(STO, level - mk->level, mk->address);//?????????????????
				}
				else if (mk->kind == ID_REFERENCE)
				{
					expression(fsys);
					gen(MOV, level - mk->level, mk->address);
					gen(STOR, /*level - mk->level*/level, 0);
					//gen(STO, level - mk->level, add_register);
				}
				else {	//����Ǵ���ַ���ò���?
					gen(LOD, level - mk->level, mk->address);
					expression(fsys);
					gen(STOA, 1, 0);
				}
			}
		}
		else if (table[i].kind == ID_PROCEDURE)
		{
			call(i, fsys);
		}
		else
		{
			error(12); // Illegal assignment.
			i = 0;
		}
	}
	else if (sym == SYM_IF)
	{ // if statement
		getsym();
		set1 = createset(SYM_THEN, SYM_DO, SYM_NULL);
		set = uniteset(set1, fsys);
		condition(set);//?????????????? 
		if (!count0)//?????????????=0 
		{
			falselist[count0++] = cx;
			gen(JMP, 0, 0);
		}
		while (count1)
		{
			count1--;
			code[truelist[count1]].a = cx;
		}
		if (sym == SYM_THEN)
		{
			getsym();
		}
		else
		{
			error(16); // 'then' expected.
		}
		set2 = createset(SYM_ELSE, SYM_NULL);
		set3 = uniteset(set2, fsys);
		false0 = 0;
		while (false0<count0)
		{
			list0[false0] = falselist[false0];
			false0++;
		}
		count0=0;
		statement(set3);
		while (count0 < false0)
		{
			falselist[count0] = list0[count0];
			count0++;
		}
		if (sym == SYM_ELSE)//?????????else 
		{
			jump[list++] = cx;
			gen(JMP, 0, 0);
			while (count0)
			{
				count0--;
				code[falselist[count0]].a = cx;
			}//??????????????????else??????��??? 
			getsym();
			statement(fsys);
		}
		while (count0)
		{
			count0--;
			code[falselist[count0]].a = cx;
		}
		while (list--)
			code[jump[list]].a = cx;
		destroyset(set3);
		destroyset(set2);
	}
	else if (sym == SYM_BEGIN)
	{ // block
		getsym();
		set1 = createset(SYM_SEMICOLON, SYM_END, SYM_NULL);
		set = uniteset(set1, fsys);
		statement(set);
		while (sym == SYM_SEMICOLON || inset(sym, statbegsys))
		{
			if (sym == SYM_SEMICOLON)
			{
				getsym();
			}
			else
			{
				error(10);
			}
			statement(set);
		} // while
		destroyset(set1);
		destroyset(set);
		if (sym == SYM_END)
		{
			getsym();
		}
		else
		{
			error(17); // ';' or 'end' expected.
		}
	}
	else if (sym == SYM_PRT)
	{// build-in function print()
		getsym();
		if (sym != SYM_LPAREN)
		{
			error(35);// need a '('
		}
		else
		{//sym == SYM_LPAREN
			do {
				getsym();
				if (sym == SYM_RPAREN)
				{// never here if print() has arguments
					break;
				}
				//????????????????????,???print??????????? print(E1, E2,.... , En)??????????��???????????????? 
				set = uniteset(createset(SYM_RPAREN, SYM_COMMA, SYM_NULL), fsys);
				expression(set);
				gen(PTOP, 0, 0);
				destroyset(set);
				ex++;
			} while (sym == SYM_COMMA);
			if (ex == 0)
			{
				gen(PRT, 0, 0);
				getsym();
			}
			else if (ex > 0)
			{
				getsym();// semicolon				
			}
		}
	}
	else if (sym == SYM_GOTO)
	{
		flag = 0;
		getsym();
		if (sym != SYM_IDENTIFIER)
			error(8);
		else
		{
			getsym();
			if (sym != SYM_SEMICOLON)
				error(5);
			else
			{
				strcpy(gotochar[gotonum], id);
				gotoa[gotonum] = cx;
				gotonum++;
				gen(JMP, 0, 0);
			}
		}
	}
	else if(sym == SYM_ARRAY)
	{
		if(!(i = array_position()))
			error(11);
		else
		{
			j = array_table[i].address;
			mk = (mask*) &table[j];
			gen(LIT, 0, 0);
			while(ch == '[')
			{
				d++;
				getch();
				getsym();
				set = uniteset(createset(SYM_RSPAREN, SYM_NULL),fsys);
				expression(set);
				destroyset(set);
				gen(LIT, 0, array_table[i].size[d]);
				gen(OPR, 0, OPR_MUL);
				gen(OPR, 0, OPR_ADD);
			}
			d = 0;
		}
		getsym();
		if(sym == SYM_BECOMES)
			getsym();
		else
			error(13);
		j = array_table[i].address;
		mk = (mask *)&table[j];
		if(j){
			if(mk -> kind == ID_VARIABLE){
				set = uniteset(createset(SYM_RSPAREN, SYM_NULL),fsys);
				expression(set);
				destroyset(set);
				gen(STA, level - mk->level, mk->address);
			}
			else if(mk -> kind == ARR_PARAREF){
				gen(LOD, level - mk -> level, mk->address);
				gen(OPR, 0, OPR_ADD);
				set = uniteset(createset(SYM_RSPAREN, SYM_NULL),fsys);
				expression(set);
				destroyset(set);
				gen(STOA, 1, 0);
			}
		}
		
		
	}
	else if (sym == SYM_WHILE)
	{ // while statement
		cx1 = cx;//cx1�����˵�ǰ�����? 
		loop++;//����ѭ�� 
		getsym();
		set1 = createset(SYM_DO, SYM_NULL);
		set = uniteset(set1, fsys);
		loop1 = cx;
		condition(set);
	if (!count0)
	{
		falselist[count0++] = cx;
		gen(JMP, 0, 0);
	}
	while (count1)
	{
		count1--;
		code[truelist[count1]].a = cx;
	}
	destroyset(set1);
	destroyset(set);

	//cx2 = cx;
	//gen(JPC, 0, 0);
	if (sym == SYM_DO)
	{
		getsym();
	}
	else
	{
		error(18); // 'do' expected.
	}
	false0 = 0;
	while (false0 < count0)
	{
		list0[false0] = falselist[false0];
		false0++;
	}
	count0 = 0;
	loop2 = loop1;
	statement(fsys);
	loop1 = loop2;
	while (count0 < false0)
	{
		falselist[count0] = list0[count0];
		count0++;
	}
	gen(JMP, 0, cx1);
	while (count0)
	{
		count0--;
		code[falselist[count0]].a = cx;
	}
	loop--;
	}
		
	test(fsys, phi, 19);
} // statement

int n = 0;
char temp[MAXIDLEN + 1];
//////////////////////////////////////////////////////////////////////
void block(symset fsys)
{
	int cx0; // initial code index
	mask* mk;
	mask* mk1;
	int block_dx;
	int savedTx,savedax;
	int t,i;
	symset set1, set;
	proceduretab* pb;
	dx = 3 ;
	int n0 = n;
	block_dx = dx;
	mk = (mask*)&table[tx - n];
	mk->address = cx;
	gen(JMP, 0, 0);
	if (level > MAXLEVEL)
	{
		error(32); // There are too many levels.
	}
	do
	{
		if (sym == SYM_CONST)
		{ // constant declarations
			getsym();
			do
			{
				constdeclaration();
				while (sym == SYM_COMMA)
				{
					getsym();
					constdeclaration();
				}
				if (sym == SYM_SEMICOLON)
				{
					getsym();
				}
				else
				{
					error(5); // Missing ',' or ';'.
				}
			} while (sym == SYM_IDENTIFIER);
		} // if

		if (sym == SYM_VAR)
		{ // variable declarations
			getsym();
			do
			{
				vardeclaration();
				while (sym == SYM_COMMA)
				{
					getsym();
					vardeclaration();
				}
				if (sym == SYM_SEMICOLON)
				{
					getsym();
				}
				else
				{
					error(5); // Missing ',' or ';'.
				}
			} while (sym == SYM_IDENTIFIER || sym == SYM_AND|| sym == SYM_ARRAY);
		} // if
		block_dx = dx; //save dx before handling procedure call!
		while (!level && sym == SYM_PROCEDURE)	//???????????????main??????????????
		{ // procedure declarations
			getsym();
			pb = &table2[tx2];
			if (sym == SYM_IDENTIFIER)
			{
				enter(ID_PROCEDURE);
				strcpy(pb->name, id);
				getsym();
			}
			else
			{
				error(4); // There must be an identifier to follow 'const', 'var', or 'procedure'.
			}
			n = 0;
			//save_dx = dx;
			savedTx = tx;
			savedax = ax;
			dx = 3;
			level++;
			if (sym == SYM_LPAREN)
			{
				do
				{
					getsym();
					if(sym == SYM_ARRAY){
						t = tx;
						vardeclaration();
						tx = t + 1;
						mk1 = (mask*)&table[tx];
						mk1->kind = ARR_PARAREF;	
						n++;
						pb->type[n]=2;
						pb->array[n]=array_table[ax];//
						
					}
					else if (sym == SYM_IDENTIFIER)
					{
						vardeclaration();	//????????
						n++;			//???????????
						pb->type[n] = 0;	//0??????
					}
					else if(sym == SYM_ADDRESS)	//����&**********
					{
						getsym();
						vardeclaration();
						mk1 = (mask*)&table[tx];
						mk1->kind = ID_PARAREF;	//��ʶ���Ǵ���ַ����
						n++;
						pb->type[n] = 1;		//1��ʾ����ַ
					}
					
					//��������ַ�����޸�-1��-2...-n
					t = n;
					for(i = savedTx+1; i<= tx; i++){
						mk1 = (mask*) &table[i];
						mk1->address = -(t--);
					}
				} while (sym == SYM_COMMA);
				pb->varnum = n;

				if (sym == SYM_RPAREN)
				{
					getsym();//????????????
				}
				else
				{
					error(19);		//?????????
					getsym();
				}
				if (sym == SYM_SEMICOLON)
				{
					getsym();
				}
				else
				{
					error(5); // Missing ',' or ';'.
				}

			}
			//dx = save_dx;

			set1 = createset(SYM_SEMICOLON, SYM_NULL);
			set = uniteset(set1, fsys);
			block(set);
			destroyset(set1);
			destroyset(set);
			tx = savedTx;
			ax = savedax;
			level--;

			if (sym == SYM_SEMICOLON)
			{
				getsym();
				set1 = createset(SYM_IDENTIFIER, SYM_PROCEDURE, SYM_NULL);
				set = uniteset(statbegsys, set1);
				test(set, fsys, 6);
				destroyset(set1);
				destroyset(set);
			}
			else
			{
				error(5); // Missing ',' or ';'.
			}
		} // while
		dx = block_dx; //restore dx after handling procedure call!
		set1 = createset(SYM_IDENTIFIER,SYM_ARRAY, SYM_NULL);
		set = uniteset(statbegsys, set1);
		test(set, declbegsys, 7);
		destroyset(set1);
		destroyset(set);
	} while (inset(sym, declbegsys));

	code[mk->address].a = cx;
	mk->address = cx;
	cx0 = cx;
	gen(INT, 0, block_dx);
	print_codetemp(level);// TODO: ????��???
	set1 = createset(SYM_SEMICOLON, SYM_END, SYM_NULL);
	set = uniteset(set1, fsys);
	statement(set);
	destroyset(set1);
	destroyset(set);
	gen(OPR, 0, OPR_RET); // return
	//gen(POPN, 0, n0);
	test(fsys, phi, 8); // test for error: Follow the statement is an incorrect symbol.
	listcode(cx0, cx);
} // block

//////////////////////////////////////////////////////////////////////
int base(int stack[], int currentLevel, int levelDiff)
{
	int b = currentLevel;

	while (levelDiff--)
		b = stack[b];
	return b;
} // base

int varposition(int stack[], int currentbase, int diff, int a)
{
	int b = currentbase;
	if (diff == 1)		//??????????????��????????????��??
	{
		b = stack[b + 1];	//?????????????
	}
	return b + a;
}

//////////////////////////////////////////////////////////////////////
// interprets and executes codes.
void interpret()
{
	int pc;        // program counter
	int stack[STACKSIZE];
	int use;
	int top;       // top of stack
	int b;  instruction i; // instruction register
	int temp;      // the temporary variable of the return
	printf("Begin executing PL/0 program.\n");
	pc = 0;
	b = 1;
	top = 3;
	stack[1] = stack[2] = stack[3] = 0;
	do
	{
		i = code[pc++];
		switch (i.f)
		{
		case LIT:
			stack[++top] = i.a;
			break;
		case OPR:
			switch (i.a) // operator
			{
			case OPR_RET:
				top = b - 1 ;	
				pc = stack[top + 3];
				b = stack[top + 2];
				break;
			case OPR_NEG:
				stack[top] = -stack[top];
				break;
			case OPR_ADD:
				top--;
				stack[top] += stack[top + 1];
				break;
			case OPR_MIN:
				top--;
				stack[top] -= stack[top + 1];
				break;
			case OPR_MUL:
				top--;
				stack[top] *= stack[top + 1];
				break;
			case OPR_DIV:
				top--;
				if (stack[top + 1] == 0)
				{
					fprintf(stderr, "Runtime Error: Divided by zero.\n");
					fprintf(stderr, "Program terminated.\n");
					continue;
				}
				stack[top] /= stack[top + 1];
				break;
			case OPR_ODD:
				stack[top] %= 2;
				break;
			case OPR_EQU:
				top--;
				stack[top] = stack[top] == stack[top + 1];
				break;
			case OPR_NEQ:
				top--;
				stack[top] = stack[top] != stack[top + 1];
			case OPR_LES:
				top--;
				stack[top] = stack[top] < stack[top + 1];
				break;
			case OPR_GEQ:
				top--;
				stack[top] = stack[top] >= stack[top + 1];
				break;
			case OPR_GTR:
				top--;
				stack[top] = stack[top] > stack[top + 1];
				break;
			case OPR_LEQ:
				top--;
				stack[top] = stack[top] <= stack[top + 1];
				break;
			case OPR_NOT:
				if (stack[top] != 0) stack[top] = 0;
				else stack[top] = 1;
				break;
			case OPR_AND:
				top--;
				if ((stack[top] != 0) && stack[top + 1] != 0)
					stack[top] = 1;
				else stack[top] = 0;
				break;
			case OPR_OR:
				top--;
				if ((stack[top] == 0) && stack[top + 1] == 0)
					stack[top] = 0;
				else stack[top] = 1;
				break;
			} // switch
			break;
		case LOD:
			stack[++top] = stack[base(stack, b, i.l) + i.a];
			break;
		case STO:
			stack[base(stack, b, i.l) + i.a] = stack[top];
			//printf("%d\n", stack[top]);
			top--;
			break;
		case CAL:
			stack[top + 1] = base(stack, b, i.l);
			// generate new block mark
			stack[top + 2] = b;
			stack[top + 3] = pc;
			b = top + 1;
			pc = i.a;
			break;
		case POP:
			if (i.a)
				top--;
			else if (use)
			{
				top--;
				use = 0;
			}
			break;
		case LODA://
			stack[top]=stack[varposition(stack,b,i.l,stack[top])];//
			break;
			
		case STOA://
			stack[varposition(stack,b,i.l,stack[top-1])] = stack[top];//top is result,top-1 is address
			top-=2;
			break;

		case INT:
			top += i.a;
			break;
		case JMP:
			pc = i.a;
			break;
		case JPC:
			if (stack[top] == 0)
				pc = i.a;
			top--;
			break;
		case JZ:
			if (stack[top] == 0)
				pc = i.a;
			top--;
			break;
		case JG:
			if (stack[top - 1] > stack[top])
				pc = i.a;
			top--;
			break;
		case JL:
			if (stack[top - 1] < stack[top])
				pc = i.a;
			top--;
			break;
		case JGE:
			if (stack[top - 1] >= stack[top])
				pc = i.a;
			top--;
			break;
		case JLE:
			if (stack[top - 1] <= stack[top])
				pc = i.a;
			top--;
			break;
		case JE:
			if (stack[top - 1] == stack[top])
				pc = i.a;
			top--;
			break;
		case JNE:
			if (stack[top - 1] != stack[top])
				pc = i.a;
			top--;
			break;
		case JNZ:
			if (stack[top] != 0)
				pc = i.a;
			top--;
			break;
		case REV:
			temp = stack[top];
			top = b;
			pc = stack[top + 2];
			b = stack[top + 1];
			stack[top] = temp;
			use = 1;
			printf("%d\n", stack[top]);
			break;
		case PRT:
			printf("\n");
			break;
		case PTOP:
			printf("%d\n", stack[top]);
			break;
		case MOV:
			add_register = stack[base(stack, b, i.l)+ i.a];
			break;
		case STOR:
			stack[base(stack, b, i.l) + add_register] = stack[top];
			top--;
			break;
		case LODR:
			stack[++top] = stack[base(stack, b, i.l) + add_register];
			break;
		case LEA:
			stack[++top] = i.a;
			break;
		case LDA:
			stack[top] = stack[base(stack, b, i.l) + i.a + stack[top]];
			break;
		case STA:
			stack[base(stack, b, i.l) + i.a + stack[top-1]] = stack[top];
			top--;
			break;
		case POPN:
			top = top - i.a;
			break;
		case RAN:
			if(i.a == 0)
			{
				stack[++top] = rand() % 1000;
			}
			else
			{
				stack[++top] = rand() % i.a;
			}			
			break;
		default:
			break;
		} // switch
	} while (pc);
	printf("End executing PL/0 program.\n");
} // interpret

//////////////////////////////////////////////////////////////////////
int main()
{
	FILE* hbin;
	char s[80];
	int i, j;
	symset set, set1, set2;

	srand((int)time(0));

	printf("Please input source file name: "); // get file name to be compiled
	scanf("%s", s);
	if ((infile = fopen(s, "r")) == NULL)
	{
		printf("File %s can't be opened.\n", s);
		exit(1);
	}

	phi = createset(SYM_NULL);
	relset = createset(SYM_EQU, SYM_NEQ, SYM_LES, SYM_LEQ, SYM_GTR, SYM_GEQ, SYM_NULL);

	// create begin symbol sets
	declbegsys = createset(SYM_CONST, SYM_VAR, SYM_PROCEDURE, SYM_NULL);
	statbegsys = createset(SYM_BEGIN, SYM_CALL, SYM_IF, SYM_WHILE, SYM_GOTO, SYM_PRT, SYM_IDENTIFIER, SYM_NULL);
	facbegsys = createset(SYM_IDENTIFIER, SYM_NUMBER, SYM_LPAREN, SYM_MINUS, SYM_RANDOM, SYM_ARRAY,SYM_NULL);

	err = cc = cx = ll = 0; // initialize global variables
	ch = ' ';
	kk = MAXIDLEN;
	for (i = 0; i < 10; i++)
	{
		labela[i] = 0;
		gotoa[i] = 0;
	}

	getsym();

	set1 = createset(SYM_PERIOD, SYM_NULL);
	set2 = uniteset(declbegsys, statbegsys);
	set = uniteset(set1, set2);
	block(set);
	for (i = 0; i < gotonum; i++)
	{
		for (j = 0; j < labelnum; j++)
			if (!strcmp(gotochar[i], labelchar[j]))
				code[gotoa[i]].a = labela[j];

	}
	destroyset(set1);
	destroyset(set2);
	destroyset(set);
	destroyset(phi);
	destroyset(relset);
	destroyset(declbegsys);
	destroyset(statbegsys);
	destroyset(facbegsys);

	if (sym != SYM_PERIOD)
		error(9); // '.' expected.
	if (err == 0)
	{
		hbin = fopen("hbin.txt", "w");
		for (i = 0; i < cx; i++)
			fwrite(&code[i], sizeof(instruction), 1, hbin);
		fprintf(hbin, "%5d %s\t%d\t%d\n", i, mnemonic[code[i].f], code[i].l, code[i].a);
		fclose(hbin);
	}
	if (err == 0)
		interpret();
	else
		printf("There are %d error(s) in PL/0 program.\n", err);
	listcode(0, cx);
	return 0;
} // main

//////////////////////////////////////////////////////////////////////
// eof pl0.c


